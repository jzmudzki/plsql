create or replace PACKAGE DOCUMENTS_PESEL AS 

function VALIDATE_PESEL (pesel int) return varchar2;
procedure PRINT_DOCUMENTS;

END DOCUMENTS_PESEL;