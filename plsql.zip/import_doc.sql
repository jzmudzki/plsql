create or replace PROCEDURE IMPORT_CSV AS 

/*
	DANE - directory declared using CREATE DIRECTORY clause
	TEST.CSV - file with data to import, format file: NAME;DESCRIPTION
*/

file utl_file.file_type;
temp_data varchar2(500);

begin

    file:=utl_file.fopen('DANE','TEST.CSV','r');
  loop
    utl_file.get_line(file,temp_data);
      insert into documents (document_name, document_description) 
        values ((REGEXP_SUBSTR(temp_data,'[^;]+',1,1)), (REGEXP_SUBSTR(temp_data,'[^;]+',1,2)));
  end loop;
  
  exception
    when others then
      utl_file.fclose(file);

END IMPORT_CSV;