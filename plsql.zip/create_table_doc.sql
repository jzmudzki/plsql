CREATE SEQUENCE DOCUMENTS_S;

create table DOCUMENTS (
 "DOCUMENT_ID" int DEFAULT DOCUMENTS_S.NEXTVAL,
 "DOCUMENT_NAME" varchar2(50) not null,
 "DOCUMENT_DESCRIPTION" varchar2(255),
 "RECORD_TIMESTAMP" timestamp not null,
 "TIMESTAMP" timestamp not null,
 "RECORD_USER_ID" varchar2(50) not null,
 "USER_ID" varchar2(50) not null,
 primary key ("DOCUMENT_ID")
);

