create or replace trigger TRIG_UPDATE_DOCUMENTS 
before update on DOCUMENTS 
for each row

BEGIN

  :new."TIMESTAMP" := current_timestamp;
  :new."USER_ID" := user;

END;