SPOOL C:\test.log

CREATE SEQUENCE DOCUMENTS_S;

create table DOCUMENTS (
 "DOCUMENT_ID" int DEFAULT DOCUMENTS_S.NEXTVAL,
 "DOCUMENT_NAME" varchar2(50) not null,
 "DOCUMENT_DESCRIPTION" varchar2(255),
 "RECORD_TIMESTAMP" timestamp not null,
 "TIMESTAMP" timestamp not null,
 "RECORD_USER_ID" varchar2(50) not null,
 "USER_ID" varchar2(50) not null,
 primary key ("DOCUMENT_ID")
);

SET DEFINE OFF;

Insert into SYSTEM.DOCUMENTS (DOCUMENT_ID,DOCUMENT_NAME,DOCUMENT_DESCRIPTION,RECORD_TIMESTAMP,TIMESTAMP,RECORD_USER_ID,USER_ID) values (1,'2','5',to_timestamp('05-AUG-18 12.58.05.491000000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('05-AUG-18 12.58.05.491000000 PM','DD-MON-RR HH.MI.SSXFF AM'),'SYSTEM','SYSTEM');
Insert into SYSTEM.DOCUMENTS (DOCUMENT_ID,DOCUMENT_NAME,DOCUMENT_DESCRIPTION,RECORD_TIMESTAMP,TIMESTAMP,RECORD_USER_ID,USER_ID) values (2,'1','22',to_timestamp('05-AUG-18 01.00.35.807000000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('05-AUG-18 01.00.47.306000000 PM','DD-MON-RR HH.MI.SSXFF AM'),'SYSTEM','SYSTEM');
Insert into SYSTEM.DOCUMENTS (DOCUMENT_ID,DOCUMENT_NAME,DOCUMENT_DESCRIPTION,RECORD_TIMESTAMP,TIMESTAMP,RECORD_USER_ID,USER_ID) values (4,'rr',null,to_timestamp('05-AUG-18 01.12.47.558000000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('05-AUG-18 01.12.47.558000000 PM','DD-MON-RR HH.MI.SSXFF AM'),'SYSTEM','SYSTEM');
Insert into SYSTEM.DOCUMENTS (DOCUMENT_ID,DOCUMENT_NAME,DOCUMENT_DESCRIPTION,RECORD_TIMESTAMP,TIMESTAMP,RECORD_USER_ID,USER_ID) values (5,'ert',null,to_timestamp('05-AUG-18 01.13.03.720000000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('05-AUG-18 01.13.03.720000000 PM','DD-MON-RR HH.MI.SSXFF AM'),'SYSTEM','SYSTEM');
Insert into SYSTEM.DOCUMENTS (DOCUMENT_ID,DOCUMENT_NAME,DOCUMENT_DESCRIPTION,RECORD_TIMESTAMP,TIMESTAMP,RECORD_USER_ID,USER_ID) values (6,'dfgh',null,to_timestamp('05-AUG-18 01.13.09.121000000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('05-AUG-18 01.13.09.121000000 PM','DD-MON-RR HH.MI.SSXFF AM'),'SYSTEM','SYSTEM');
Insert into SYSTEM.DOCUMENTS (DOCUMENT_ID,DOCUMENT_NAME,DOCUMENT_DESCRIPTION,RECORD_TIMESTAMP,TIMESTAMP,RECORD_USER_ID,USER_ID) values (7,'dfgh',null,to_timestamp('05-AUG-18 01.13.14.358000000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('05-AUG-18 01.13.14.358000000 PM','DD-MON-RR HH.MI.SSXFF AM'),'SYSTEM','SYSTEM');
Insert into SYSTEM.DOCUMENTS (DOCUMENT_ID,DOCUMENT_NAME,DOCUMENT_DESCRIPTION,RECORD_TIMESTAMP,TIMESTAMP,RECORD_USER_ID,USER_ID) values (8,'dfgh',null,to_timestamp('05-AUG-18 01.13.25.312000000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('05-AUG-18 01.13.25.312000000 PM','DD-MON-RR HH.MI.SSXFF AM'),'SYSTEM','SYSTEM');
Insert into SYSTEM.DOCUMENTS (DOCUMENT_ID,DOCUMENT_NAME,DOCUMENT_DESCRIPTION,RECORD_TIMESTAMP,TIMESTAMP,RECORD_USER_ID,USER_ID) values (9,'dfgh',null,to_timestamp('05-AUG-18 01.13.25.326000000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('05-AUG-18 01.13.25.326000000 PM','DD-MON-RR HH.MI.SSXFF AM'),'SYSTEM','SYSTEM');
Insert into SYSTEM.DOCUMENTS (DOCUMENT_ID,DOCUMENT_NAME,DOCUMENT_DESCRIPTION,RECORD_TIMESTAMP,TIMESTAMP,RECORD_USER_ID,USER_ID) values (10,'dfg',null,to_timestamp('05-AUG-18 01.13.25.326000000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('05-AUG-18 01.13.25.326000000 PM','DD-MON-RR HH.MI.SSXFF AM'),'SYSTEM','SYSTEM');
Insert into SYSTEM.DOCUMENTS (DOCUMENT_ID,DOCUMENT_NAME,DOCUMENT_DESCRIPTION,RECORD_TIMESTAMP,TIMESTAMP,RECORD_USER_ID,USER_ID) values (11,'xcn',null,to_timestamp('05-AUG-18 01.13.25.326000000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('05-AUG-18 01.13.25.326000000 PM','DD-MON-RR HH.MI.SSXFF AM'),'SYSTEM','SYSTEM');
Insert into SYSTEM.DOCUMENTS (DOCUMENT_ID,DOCUMENT_NAME,DOCUMENT_DESCRIPTION,RECORD_TIMESTAMP,TIMESTAMP,RECORD_USER_ID,USER_ID) values (12,'xgh',null,to_timestamp('05-AUG-18 01.13.25.326000000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('05-AUG-18 01.13.25.326000000 PM','DD-MON-RR HH.MI.SSXFF AM'),'SYSTEM','SYSTEM');
Insert into SYSTEM.DOCUMENTS (DOCUMENT_ID,DOCUMENT_NAME,DOCUMENT_DESCRIPTION,RECORD_TIMESTAMP,TIMESTAMP,RECORD_USER_ID,USER_ID) values (21,'trenn','dddd222',to_timestamp('06-AUG-18 10.03.10.469000000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('06-AUG-18 10.03.31.813000000 PM','DD-MON-RR HH.MI.SSXFF AM'),'SYSTEM','SYSTEM');
Insert into SYSTEM.DOCUMENTS (DOCUMENT_ID,DOCUMENT_NAME,DOCUMENT_DESCRIPTION,RECORD_TIMESTAMP,TIMESTAMP,RECORD_USER_ID,USER_ID) values (22,'NAME_TEST','DESCRIPTION_TEST',to_timestamp('07-AUG-18 10.52.53.806000000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('07-AUG-18 10.52.53.806000000 PM','DD-MON-RR HH.MI.SSXFF AM'),'SYSTEM','SYSTEM');
Insert into SYSTEM.DOCUMENTS (DOCUMENT_ID,DOCUMENT_NAME,DOCUMENT_DESCRIPTION,RECORD_TIMESTAMP,TIMESTAMP,RECORD_USER_ID,USER_ID) values (23,'NAME_TEST2','DESCRIPTION_TEST2',to_timestamp('07-AUG-18 10.52.53.806000000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('07-AUG-18 10.52.53.806000000 PM','DD-MON-RR HH.MI.SSXFF AM'),'SYSTEM','SYSTEM');
Insert into SYSTEM.DOCUMENTS (DOCUMENT_ID,DOCUMENT_NAME,DOCUMENT_DESCRIPTION,RECORD_TIMESTAMP,TIMESTAMP,RECORD_USER_ID,USER_ID) values (24,'NAME_TEST33','DESCRIPTION_TEST33',to_timestamp('07-AUG-18 10.54.09.574000000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('07-AUG-18 10.54.09.574000000 PM','DD-MON-RR HH.MI.SSXFF AM'),'SYSTEM','SYSTEM');
Insert into SYSTEM.DOCUMENTS (DOCUMENT_ID,DOCUMENT_NAME,DOCUMENT_DESCRIPTION,RECORD_TIMESTAMP,TIMESTAMP,RECORD_USER_ID,USER_ID) values (25,'NAME_TEST4','DESCRIPTION_TEST44',to_timestamp('07-AUG-18 10.54.09.574000000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('07-AUG-18 10.54.09.574000000 PM','DD-MON-RR HH.MI.SSXFF AM'),'SYSTEM','SYSTEM');
Insert into SYSTEM.DOCUMENTS (DOCUMENT_ID,DOCUMENT_NAME,DOCUMENT_DESCRIPTION,RECORD_TIMESTAMP,TIMESTAMP,RECORD_USER_ID,USER_ID) values (26,'name_test5',null,to_timestamp('07-AUG-18 10.54.09.574000000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('07-AUG-18 10.54.09.574000000 PM','DD-MON-RR HH.MI.SSXFF AM'),'SYSTEM','SYSTEM');

commit;

create or replace trigger TRIG_INSERT_DOCUMENTS 
before insert ON DOCUMENTS 
for each row

BEGIN

  :new."RECORD_TIMESTAMP" := current_timestamp;
  :new."TIMESTAMP" := current_timestamp;
  :new."RECORD_USER_ID" := user;
  :new."USER_ID" := user;

END;
/

create or replace trigger TRIG_UPDATE_DOCUMENTS 
before update on DOCUMENTS 
for each row

BEGIN

  :new."TIMESTAMP" := current_timestamp;
  :new."USER_ID" := user;

END;
/

create or replace PACKAGE DOCUMENTS_PESEL AS 

function VALIDATE_PESEL (pesel int) return varchar2;
procedure PRINT_DOCUMENTS;

END DOCUMENTS_PESEL;
/

CREATE OR REPLACE
PACKAGE BODY DOCUMENTS_PESEL AS

  function VALIDATE_PESEL (pesel int) return varchar2 is
  
   type type_pesel is varray(11) OF int(1);
   
    temp_pesel varchar(11);
    weights type_pesel := type_pesel(1,3,7,9,1,3,7,9,1,3,1);
    checksum integer := 0;
    
BEGIN

  temp_pesel := to_char(pesel);
  
  if length(pesel) = 11 then
    for i in 1..weights.count
      loop
        checksum := checksum + to_number(substr(temp_pesel,i,1)) * weights(i);
      end loop;
    
    IF MOD(checksum, 10) = 0 THEN
      return 'true';
    else return 'false';
    end if;
  else return 'false';
  end if;
  
 EXCEPTION WHEN OTHERS THEN
 return 'false';
    
END VALIDATE_PESEL;

  procedure PRINT_DOCUMENTS AS

  cursor temp_doc is
    select * from documents;

BEGIN
  
  for i_doc in temp_doc loop  
    if i_doc.document_description is not null
      then dbms_output.put_line(i_doc.document_name);
      else dbms_output.put_line('No Description');   
    end if;
  end loop;

  END PRINT_DOCUMENTS;

END DOCUMENTS_PESEL;
/

create or replace PROCEDURE IMPORT_CSV AS 

/*
	DANE - directory declared using CREATE DIRECTORY clause
	TEST.CSV - file with data to import, format file: NAME;DESCRIPTION
*/

file utl_file.file_type;
temp_data varchar2(500);

begin

    file:=utl_file.fopen('DANE','TEST.CSV','r');
  loop
    utl_file.get_line(file,temp_data);
      insert into documents (document_name, document_description) 
        values ((REGEXP_SUBSTR(temp_data,'[^;]+',1,1)), (REGEXP_SUBSTR(temp_data,'[^;]+',1,2)));
  end loop;
  
  exception
    when others then
      utl_file.fclose(file);

END IMPORT_CSV;
/

SPOOL OFF