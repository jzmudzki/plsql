create or replace trigger TRIG_INSERT_DOCUMENTS 
before insert ON DOCUMENTS 
for each row

BEGIN

  :new."RECORD_TIMESTAMP" := current_timestamp;
  :new."TIMESTAMP" := current_timestamp;
  :new."RECORD_USER_ID" := user;
  :new."USER_ID" := user;

END;