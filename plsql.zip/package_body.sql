CREATE OR REPLACE
PACKAGE BODY DOCUMENTS_PESEL AS

  function VALIDATE_PESEL (pesel int) return varchar2 is
  
   type type_pesel is varray(11) OF int(1);
   
    temp_pesel varchar(11);
    weights type_pesel := type_pesel(1, 3, 7, 9, 1, 3, 7,9,1,3,1);
    checksum integer := 0;
    
BEGIN

  temp_pesel := to_char(pesel);
  
  if length(pesel) = 11 then
    for i in 1..weights.count
      loop
        checksum := checksum + to_number(substr(temp_pesel,i,1)) * weights(i);
      end loop;
    
    IF MOD(checksum, 10) = 0 THEN
      return 'true';
    else return 'false';
    end if;
  else return 'false';
  end if;
  
 EXCEPTION WHEN OTHERS THEN
 return 'false';
    
END VALIDATE_PESEL;

  procedure PRINT_DOCUMENTS AS

  cursor temp_doc is
    select * from documents;

BEGIN
  
  for i_doc in temp_doc loop  
    if i_doc.document_description is not null
      then dbms_output.put_line(i_doc.document_name);
      else dbms_output.put_line('No Description');   
    end if;
  end loop;

  END PRINT_DOCUMENTS;

END DOCUMENTS_PESEL;